import React, { useState } from 'react';
import {
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { formatPrice, MENU_PRODUCTS } from '@/constants/menu';
import { useCart, type PaymentMethod } from '@/context/CartContext';
import { useColors } from '@/hooks/useColors';

const WHATSAPP_NUMBER = '258871528829';

export default function CheckoutScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    cart,
    cartCount,
    subtotal,
    deliveryFee,
    total,
    createDemoOrder,
  } = useCart();
  const [customerName, setCustomerName] = useState('');
  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | null>(null);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function finishViaWhatsApp() {
    if (!customerName.trim() || !address.trim()) {
      setError('Preencha seu nome e a morada de entrega.');
      return;
    }
    if (cartCount === 0) {
      setError('Seu carrinho está vazio.');
      return;
    }

    const itemLines = cart.flatMap((line) => {
      const product = MENU_PRODUCTS.find(
        (menuProduct) => menuProduct.id === line.productId,
      );
      return product
        ? [
            `${line.quantity} × ${product.name} — ${formatPrice(
              product.price * line.quantity,
            )}`,
          ]
        : [];
    });

    if (itemLines.length === 0) {
      setError('Não foi possível encontrar os produtos deste pedido.');
      return;
    }

    const paymentPreference =
      paymentMethod === 'emola'
        ? 'eMola'
        : paymentMethod === 'mpesa'
          ? 'M-Pesa'
          : 'A combinar no WhatsApp';
    const message = [
      'Olá, NacoChicken! Gostaria de finalizar este pedido pelo WhatsApp.',
      '',
      `Nome: ${customerName.trim()}`,
      `Morada: ${address.trim()}`,
      '',
      'Pedido:',
      ...itemLines,
      '',
      `Subtotal: ${formatPrice(subtotal)}`,
      `Taxa de entrega: ${formatPrice(deliveryFee)}`,
      `Total: ${formatPrice(total)}`,
      `Pagamento pretendido: ${paymentPreference}`,
      '',
      'Por favor, confirmem os dados e as instruções para pagamento.',
    ].join('\n');

    setError('');
    try {
      await Linking.openURL(
        `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`,
      );
    } catch {
      setError('Não foi possível abrir o WhatsApp. Tente novamente.');
    }
  }

  async function finishDemoOrder() {
    if (!customerName.trim() || !address.trim()) {
      setError('Preencha seu nome e a morada de entrega.');
      return;
    }
    if (cartCount === 0) {
      setError('Seu carrinho está vazio.');
      return;
    }
    if (!paymentMethod) {
      setError('Selecione eMola ou M-Pesa para continuar.');
      return;
    }

    setIsSubmitting(true);
    setError('');
    try {
      await createDemoOrder({ customerName, address, paymentMethod });
      router.replace('/order-success');
    } catch (checkoutError) {
      setError(
        checkoutError instanceof Error
          ? checkoutError.message
          : 'Não foi possível salvar o pedido neste aparelho.',
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.topBar,
          { paddingTop: Platform.OS === 'web' ? 67 : Math.max(insets.top, 12) + 8 },
        ]}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Voltar ao carrinho"
          testID="checkout-back-button"
          onPress={() => router.back()}
          style={({ pressed }) => [
            styles.backButton,
            { backgroundColor: colors.card, opacity: pressed ? 0.72 : 1 },
          ]}
        >
          <Feather name="arrow-left" size={19} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.topBarTitle, { color: colors.foreground }]}>
          Finalizar pedido
        </Text>
        <View style={styles.topBarSpacer} />
      </View>

      <KeyboardAwareScrollViewCompat
        style={styles.scroll}
        contentContainerStyle={[
          styles.content,
          { paddingBottom: Math.max(insets.bottom, 24) + 24 },
        ]}
        bottomOffset={72}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.demoBanner, { backgroundColor: '#f5e5bd' }]}>
          <Feather name="info" size={17} color="#75511d" />
          <View style={styles.demoBannerCopy}>
            <Text style={styles.demoBannerTitle}>Checkout de demonstração</Text>
            <Text style={styles.demoBannerText}>
              Pagamentos no app são demonstrativos. Para combinar o pagamento, use o WhatsApp.
            </Text>
          </View>
        </View>

        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          Onde entregar?
        </Text>
        <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Seu nome</Text>
        <TextInput
          accessibilityLabel="Seu nome"
          testID="checkout-name"
          value={customerName}
          onChangeText={setCustomerName}
          placeholder="Como podemos chamar você?"
          placeholderTextColor={colors.mutedForeground}
          autoCapitalize="words"
          returnKeyType="next"
          style={[
            styles.input,
            { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground },
          ]}
        />
        <Text style={[styles.fieldLabel, styles.addressLabel, { color: colors.foreground }]}>
          Morada de entrega
        </Text>
        <TextInput
          accessibilityLabel="Endereço de entrega"
          testID="checkout-address"
          value={address}
          onChangeText={setAddress}
          placeholder="Avenida, número, bairro e cidade"
          placeholderTextColor={colors.mutedForeground}
          autoCapitalize="sentences"
          returnKeyType="done"
          style={[
            styles.input,
            { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground },
          ]}
        />

        <Text style={[styles.sectionTitle, styles.paymentTitle, { color: colors.foreground }]}>
          Pagamento móvel
        </Text>
        <View style={styles.paymentOptions}>
          {([
            { id: 'mpesa', name: 'M-Pesa', detail: 'Carteira móvel' },
            { id: 'emola', name: 'eMola', detail: 'Carteira móvel' },
          ] as const).map((option) => {
            const selected = paymentMethod === option.id;
            return (
              <Pressable
                key={option.id}
                accessibilityRole="radio"
                accessibilityState={{ selected }}
                testID={`payment-${option.id}`}
                onPress={() => setPaymentMethod(option.id)}
                style={[
                  styles.paymentMethod,
                  {
                    backgroundColor: colors.card,
                    borderColor: selected ? colors.primary : colors.border,
                  },
                ]}
              >
                <View style={[styles.paymentIcon, { backgroundColor: colors.muted }]}>
                  <Feather name="smartphone" size={18} color={colors.primary} />
                </View>
                <View style={styles.paymentCopy}>
                  <Text style={[styles.paymentName, { color: colors.foreground }]}>
                    {option.name}
                  </Text>
                  <Text style={[styles.paymentCaption, { color: colors.mutedForeground }]}>
                    {option.detail}
                  </Text>
                </View>
                <View
                  style={[
                    styles.selectedDot,
                    { borderColor: selected ? colors.primary : colors.border },
                  ]}
                >
                  {selected && (
                    <View
                      style={[
                        styles.selectedDotInner,
                        { backgroundColor: colors.primary },
                      ]}
                    />
                  )}
                </View>
              </Pressable>
            );
          })}
        </View>
        <View style={[styles.securityNote, { backgroundColor: colors.muted }]}>
          <Feather name="info" size={15} color={colors.mutedForeground} />
          <Text style={[styles.securityText, { color: colors.mutedForeground }]}>
            eMola e M-Pesa aparecem como opções de demonstração. Esta versão não inicia transações.
          </Text>
        </View>

        <View style={[styles.summaryCard, { backgroundColor: colors.card }]}>
          <Text style={[styles.summaryTitle, { color: colors.foreground }]}>
            Resumo do pedido
          </Text>
          <View style={styles.summaryLine}>
            <Text style={[styles.summaryText, { color: colors.mutedForeground }]}>
              Subtotal
            </Text>
            <Text style={[styles.summaryValue, { color: colors.foreground }]}>
              {formatPrice(subtotal)}
            </Text>
          </View>
          <View style={styles.summaryLine}>
            <Text style={[styles.summaryText, { color: colors.mutedForeground }]}>
              Taxa de entrega
            </Text>
            <Text style={[styles.summaryValue, { color: colors.foreground }]}>
              {formatPrice(deliveryFee)}
            </Text>
          </View>
          <View style={[styles.totalLine, { borderColor: colors.border }]}>
            <Text style={[styles.totalText, { color: colors.foreground }]}>Total</Text>
            <Text style={[styles.totalValue, { color: colors.foreground }]}>
              {formatPrice(total)}
            </Text>
          </View>
        </View>

        {!!error && (
          <Text accessibilityRole="alert" style={styles.errorText}>
            {error}
          </Text>
        )}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Preparar pedido e abrir conversa no WhatsApp"
          testID="checkout-whatsapp-button"
          onPress={() => void finishViaWhatsApp()}
          style={({ pressed }) => [
            styles.submitButton,
            {
              backgroundColor: colors.whatsapp,
              opacity: pressed ? 0.82 : 1,
            },
          ]}
        >
          <Feather
            name="message-circle"
            size={18}
            color={colors.whatsappForeground}
          />
          <Text
            style={[
              styles.submitButtonText,
              { color: colors.whatsappForeground },
            ]}
          >
            Finalizar no WhatsApp
          </Text>
        </Pressable>
        <Text style={[styles.whatsAppHint, { color: colors.mutedForeground }]}>
          A conversa abrirá com o pedido preenchido. Confirme o envio e o pagamento no WhatsApp.
        </Text>
        <Pressable
          accessibilityRole="button"
          testID="checkout-submit"
          disabled={isSubmitting}
          onPress={() => void finishDemoOrder()}
          style={({ pressed }) => [
            styles.submitButton,
            {
              backgroundColor: colors.primary,
              opacity: pressed || isSubmitting ? 0.78 : 1,
            },
          ]}
        >
          <Text style={styles.submitButtonText}>
            {isSubmitting ? 'Salvando pedido...' : 'Salvar pedido de demonstração'}
          </Text>
          <Feather name="arrow-right" size={18} color={colors.primaryForeground} />
        </Pressable>
        <Text style={[styles.finePrint, { color: colors.mutedForeground }]}>
          Esta opção guarda o pedido neste aparelho; não o envia à loja.
        </Text>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  topBar: {
    paddingHorizontal: 20,
    paddingBottom: 13,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    width: 42,
    height: 42,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  topBarTitle: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  topBarSpacer: { width: 42 },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 20 },
  demoBanner: { flexDirection: 'row', gap: 10, padding: 13, borderRadius: 16, marginBottom: 22 },
  demoBannerCopy: { flex: 1 },
  demoBannerTitle: { color: '#593b16', fontFamily: 'Inter_700Bold', fontSize: 12 },
  demoBannerText: {
    color: '#75511d',
    fontFamily: 'Inter_400Regular',
    fontSize: 10,
    lineHeight: 15,
    marginTop: 3,
  },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 18, marginBottom: 13 },
  fieldLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 11, marginBottom: 7 },
  input: {
    height: 50,
    borderRadius: 15,
    borderWidth: 1,
    paddingHorizontal: 14,
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
  },
  addressLabel: { marginTop: 15 },
  paymentTitle: { marginTop: 24 },
  paymentOptions: { gap: 9 },
  paymentMethod: {
    minHeight: 70,
    borderWidth: 1.5,
    borderRadius: 17,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
    paddingHorizontal: 12,
  },
  paymentIcon: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  paymentCopy: { flex: 1 },
  paymentName: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  paymentCaption: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 3 },
  selectedDot: {
    width: 19,
    height: 19,
    borderWidth: 1.5,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedDotInner: { width: 9, height: 9, borderRadius: 5 },
  securityNote: { flexDirection: 'row', gap: 8, padding: 11, borderRadius: 13, marginTop: 10 },
  securityText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15 },
  summaryCard: { borderRadius: 18, padding: 16, marginTop: 19, gap: 11 },
  summaryTitle: { fontFamily: 'Inter_700Bold', fontSize: 13, marginBottom: 1 },
  summaryLine: { flexDirection: 'row', justifyContent: 'space-between' },
  summaryText: { fontFamily: 'Inter_400Regular', fontSize: 11 },
  summaryValue: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  totalLine: { borderTopWidth: 1, paddingTop: 12, marginTop: 1, flexDirection: 'row', justifyContent: 'space-between' },
  totalText: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  totalValue: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  errorText: { color: '#c44935', fontFamily: 'Inter_600SemiBold', fontSize: 11, marginTop: 13 },
  submitButton: {
    height: 54,
    borderRadius: 17,
    paddingHorizontal: 18,
    marginTop: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  submitButtonText: { color: '#fffdf9', fontFamily: 'Inter_700Bold', fontSize: 13 },
  whatsAppHint: {
    textAlign: 'center',
    fontFamily: 'Inter_400Regular',
    fontSize: 10,
    lineHeight: 15,
    marginTop: 8,
  },
  finePrint: { textAlign: 'center', fontFamily: 'Inter_400Regular', fontSize: 9, lineHeight: 14, marginTop: 9 },
});
