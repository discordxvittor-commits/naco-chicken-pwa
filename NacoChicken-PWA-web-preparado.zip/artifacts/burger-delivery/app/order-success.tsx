import React from 'react';
import {
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { formatPrice } from '@/constants/menu';
import {
  getOrderCurrency,
  getPaymentMethodLabel,
  useCart,
} from '@/context/CartContext';
import { useColors } from '@/hooks/useColors';

export default function OrderSuccessScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { orders } = useCart();
  const order = orders[0];

  return (
    <View
      style={[
        styles.screen,
        {
          backgroundColor: colors.background,
          paddingTop: Platform.OS === 'web' ? 67 : Math.max(insets.top, 12) + 12,
          paddingBottom: Math.max(insets.bottom, 24) + 16,
        },
      ]}
    >
      <View style={[styles.successMark, { backgroundColor: colors.accent }]}>
        <Feather name="check" size={31} color={colors.accentForeground} />
      </View>
      <Text style={[styles.kicker, { color: colors.primary }]}>PEDIDO REGISTRADO</Text>
      <Text style={[styles.title, { color: colors.foreground }]}>
        Obrigado, {order?.customerName.split(' ')[0] || 'por pedir'}.
      </Text>
      <Text style={[styles.body, { color: colors.mutedForeground }]}>
        Seu pedido de demonstração foi salvo neste aparelho. Ele ainda não foi enviado à hamburgueria e nenhum pagamento foi realizado.
      </Text>

      {order && (
        <View style={[styles.orderCard, { backgroundColor: colors.card }]}>
          <View style={styles.orderHeader}>
            <Text style={[styles.orderLabel, { color: colors.mutedForeground }]}>
              PEDIDO
            </Text>
            <Text style={[styles.orderNumber, { color: colors.foreground }]}>
              #{order.id.slice(-5)}
            </Text>
          </View>
          <View style={[styles.divider, { borderColor: colors.border }]} />
          {order.items.map((item) => (
            <View key={item.productId} style={styles.itemLine}>
              <Text style={[styles.itemText, { color: colors.foreground }]}>
                {item.quantity} × {item.name}
              </Text>
              <Text style={[styles.itemText, { color: colors.foreground }]}>
                {formatPrice(
                  item.unitPrice * item.quantity,
                  getOrderCurrency(order),
                )}
              </Text>
            </View>
          ))}
          <View style={[styles.divider, { borderColor: colors.border }]} />
          <View style={styles.orderHeader}>
            <Text style={[styles.totalLabel, { color: colors.foreground }]}>Total</Text>
            <Text style={[styles.totalPrice, { color: colors.foreground }]}>
              {formatPrice(order.total, getOrderCurrency(order))}
            </Text>
          </View>
          <Text style={[styles.paymentText, { color: colors.mutedForeground }]}>
            Método: {getPaymentMethodLabel(order.paymentMethod)} (demonstração)
          </Text>
          <View style={[styles.addressBox, { backgroundColor: colors.muted }]}>
            <Feather name="map-pin" size={14} color={colors.primary} />
            <Text style={[styles.addressText, { color: colors.mutedForeground }]}>
              {order.address}
            </Text>
          </View>
        </View>
      )}

      <View style={styles.spacer} />
      <Pressable
        accessibilityRole="button"
        testID="success-view-orders"
        onPress={() => router.replace('/(tabs)/orders')}
        style={({ pressed }) => [
          styles.primaryButton,
          { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
        ]}
      >
        <Text style={styles.primaryButtonText}>Ver meus pedidos</Text>
        <Feather name="arrow-right" size={18} color={colors.primaryForeground} />
      </Pressable>
      <Pressable
        accessibilityRole="button"
        testID="success-home"
        onPress={() => router.replace('/(tabs)')}
        style={styles.homeButton}
      >
        <Text style={[styles.homeButtonText, { color: colors.mutedForeground }]}>
          Voltar ao menu
        </Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, paddingHorizontal: 22, alignItems: 'center' },
  successMark: {
    width: 74,
    height: 74,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 32,
    marginBottom: 22,
  },
  kicker: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.6 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 24, letterSpacing: -0.7, marginTop: 7, textAlign: 'center' },
  body: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18, textAlign: 'center', marginTop: 9, maxWidth: 310 },
  orderCard: { width: '100%', borderRadius: 20, padding: 16, marginTop: 23 },
  orderHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  orderLabel: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.2 },
  orderNumber: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  divider: { borderTopWidth: 1, marginVertical: 13 },
  itemLine: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 9, gap: 8 },
  itemText: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  totalLabel: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  totalPrice: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  addressBox: { marginTop: 14, borderRadius: 12, padding: 10, flexDirection: 'row', gap: 8, alignItems: 'center' },
  paymentText: { fontFamily: 'Inter_500Medium', fontSize: 10, marginTop: 12 },
  addressText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15 },
  spacer: { flex: 1, minHeight: 24 },
  primaryButton: {
    width: '100%',
    height: 53,
    borderRadius: 17,
    paddingHorizontal: 17,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  primaryButtonText: { color: '#fffdf9', fontFamily: 'Inter_700Bold', fontSize: 13 },
  homeButton: { height: 46, alignItems: 'center', justifyContent: 'center' },
  homeButtonText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
});
