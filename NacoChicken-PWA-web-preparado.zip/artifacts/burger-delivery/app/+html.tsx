import { Html, Head, Main, Scripts } from 'expo-router/html';

export default function Root({ children }: { children: React.ReactNode }) {
  return (
    <Html lang="pt-MZ">
      <Head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
        <meta name="theme-color" content="#c62828" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-title" content="Naco Chicken" />
        <link rel="manifest" href="/manifest.json" />
        <link rel="icon" type="image/png" href="/favicon.png" />
        <link rel="apple-touch-icon" href="/icon-192.png" />
      </Head>
      <body>
        <Main />
        <Scripts />
        <script dangerouslySetInnerHTML={{ __html: "if ('serviceWorker' in navigator && location.protocol === 'https:') { window.addEventListener('load', function () { navigator.serviceWorker.register('/sw.js').catch(function (e) { console.warn('PWA service worker registration failed', e); }); }); }" }} />
      </body>
    </Html>
  );
}
