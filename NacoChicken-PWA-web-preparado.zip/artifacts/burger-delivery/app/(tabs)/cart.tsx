import React, { useState } from 'react';
import {
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { MENU_PRODUCTS, formatPrice } from '@/constants/menu';
import { useCart } from '@/context/CartContext';

export default function CartScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    cart,
    cartCount,
    isHydrated,
    subtotal,
    deliveryFee,
    total,
    addItem,
    removeItem,
    clearCart,
  } = useCart();
  const [isConfirmingClear, setIsConfirmingClear] = useState(false);
  const [clearCartError, setClearCartError] = useState('');

  async function confirmClearCart() {
    setClearCartError('');
    try {
      await clearCart();
      setIsConfirmingClear(false);
    } catch {
      setClearCartError('Não foi possível apagar o pedido. Tente novamente.');
    }
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: Platform.OS === 'web' ? 67 : Math.max(insets.top, 12) + 12,
            paddingBottom: 22,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={[styles.kicker, { color: colors.primary }]}>QUASE LÁ</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>Seu carrinho</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            Uma boa escolha merece chegar quentinha.
          </Text>
        </View>

        {!isHydrated ? (
          <View style={[styles.emptyCard, { backgroundColor: colors.card }]}>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              Carregando seu carrinho...
            </Text>
          </View>
        ) : cart.length === 0 ? (
          <View style={[styles.emptyCard, { backgroundColor: colors.card }]}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.muted }]}>
              <Feather name="shopping-bag" size={22} color={colors.primary} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              Ainda está vazio por aqui
            </Text>
            <Text style={[styles.emptyBody, { color: colors.mutedForeground }]}>
              Escolha seu hambúrguer favorito e ele aparece aqui.
            </Text>
            <Pressable
              accessibilityRole="button"
              testID="cart-browse-menu"
              onPress={() => router.navigate('/(tabs)')}
              style={({ pressed }) => [
                styles.primaryButton,
                { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
              ]}
            >
              <Text style={styles.primaryButtonText}>Explorar cardápio</Text>
              <Feather name="arrow-right" size={17} color={colors.primaryForeground} />
            </Pressable>
          </View>
        ) : (
          <>
            <View style={styles.orderToolbar}>
              <Text style={[styles.cartCountLabel, { color: colors.mutedForeground }]}>
                {cartCount} {cartCount === 1 ? 'item' : 'itens'} no pedido
              </Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Apagar todos os itens do pedido"
                testID="cart-clear-button"
                onPress={() => {
                  setClearCartError('');
                  setIsConfirmingClear(true);
                }}
                style={styles.clearCartButton}
              >
                <Feather name="trash-2" size={14} color={colors.destructive} />
                <Text style={[styles.clearCartText, { color: colors.destructive }]}>
                  Apagar pedido
                </Text>
              </Pressable>
            </View>
            {isConfirmingClear && (
              <View style={[styles.confirmationCard, { backgroundColor: colors.muted }]}>
                <Text style={[styles.confirmationText, { color: colors.foreground }]}>
                  Apagar todos os itens do pedido atual? Esta ação não pode ser desfeita.
                </Text>
                {!!clearCartError && (
                  <Text style={[styles.confirmationError, { color: colors.destructive }]}>
                    {clearCartError}
                  </Text>
                )}
                <View style={styles.confirmationActions}>
                  <Pressable
                    accessibilityRole="button"
                    onPress={() => setIsConfirmingClear(false)}
                    style={styles.confirmationButton}
                  >
                    <Text style={[styles.confirmationButtonText, { color: colors.foreground }]}>
                      Manter pedido
                    </Text>
                  </Pressable>
                  <Pressable
                    accessibilityRole="button"
                    testID="cart-confirm-clear"
                    onPress={() => void confirmClearCart()}
                    style={styles.confirmationButton}
                  >
                    <Text style={[styles.confirmationButtonText, { color: colors.destructive }]}>
                      Apagar tudo
                    </Text>
                  </Pressable>
                </View>
              </View>
            )}
            <View style={styles.itemsList}>
              {cart.map((line) => {
                const product = MENU_PRODUCTS.find(
                  (menuProduct) => menuProduct.id === line.productId,
                );
                if (!product) return null;
                return (
                  <View
                    key={line.productId}
                    style={[
                      styles.cartItem,
                      { backgroundColor: colors.card, borderColor: colors.border },
                    ]}
                  >
                    <Image source={product.image} style={styles.itemImage} />
                    <View style={styles.itemCopy}>
                      <Text style={[styles.itemName, { color: colors.foreground }]}>
                        {product.name}
                      </Text>
                      <Text
                        style={[styles.itemDetails, { color: colors.mutedForeground }]}
                        numberOfLines={2}
                      >
                        {product.description}
                      </Text>
                      <Text style={[styles.itemPrice, { color: colors.primary }]}>
                        {formatPrice(product.price * line.quantity)}
                      </Text>
                    </View>
                    <View style={[styles.quantityControl, { backgroundColor: colors.muted }]}>
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel={`Remover um ${product.name}`}
                        testID={`remove-${product.id}`}
                        hitSlop={6}
                        onPress={() => {
                          void removeItem(product.id);
                          void Haptics.selectionAsync();
                        }}
                        style={styles.quantityButton}
                      >
                        <Feather name="minus" size={14} color={colors.foreground} />
                      </Pressable>
                      <Text style={[styles.quantity, { color: colors.foreground }]}>
                        {line.quantity}
                      </Text>
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel={`Adicionar mais um ${product.name}`}
                        testID={`increase-${product.id}`}
                        hitSlop={6}
                        onPress={() => {
                          void addItem(product.id);
                          void Haptics.selectionAsync();
                        }}
                        style={styles.quantityButton}
                      >
                        <Feather name="plus" size={14} color={colors.foreground} />
                      </Pressable>
                    </View>
                  </View>
                );
              })}
            </View>

            <View style={[styles.summary, { backgroundColor: colors.card }]}>
              <View style={styles.summaryLine}>
                <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>
                  Subtotal
                </Text>
                <Text style={[styles.summaryValue, { color: colors.foreground }]}>
                  {formatPrice(subtotal)}
                </Text>
              </View>
              <View style={styles.summaryLine}>
                <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>
                  Taxa de entrega
                </Text>
                <Text style={[styles.summaryValue, { color: colors.foreground }]}>
                  {formatPrice(deliveryFee)}
                </Text>
              </View>
              <View style={[styles.totalLine, { borderColor: colors.border }]}>
                <Text style={[styles.totalLabel, { color: colors.foreground }]}>
                  Total
                </Text>
                <Text style={[styles.totalValue, { color: colors.foreground }]}>
                  {formatPrice(total)}
                </Text>
              </View>
            </View>
            <Pressable
              accessibilityRole="button"
              testID="cart-checkout-button"
              onPress={() => router.push('/checkout')}
              style={({ pressed }) => [
                styles.primaryButton,
                styles.checkoutButton,
                { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
              ]}
            >
              <Text style={styles.primaryButtonText}>Ir para pagamento</Text>
              <Feather name="arrow-right" size={18} color={colors.primaryForeground} />
            </Pressable>
            <Text style={[styles.demoCaption, { color: colors.mutedForeground }]}>
              Checkout demonstrativo • nenhuma cobrança será feita
            </Text>
          </>
        )}
        <View style={{ height: Platform.OS === 'web' ? 90 : 82 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 20 },
  header: { marginBottom: 22 },
  orderToolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  cartCountLabel: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  clearCartButton: { flexDirection: 'row', alignItems: 'center', gap: 5, padding: 6 },
  clearCartText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  confirmationCard: { borderRadius: 15, padding: 14, marginBottom: 12 },
  confirmationText: { fontFamily: 'Inter_500Medium', fontSize: 12, lineHeight: 18 },
  confirmationError: { fontFamily: 'Inter_500Medium', fontSize: 10, marginTop: 8 },
  confirmationActions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 12,
  },
  confirmationButton: { minHeight: 34, justifyContent: 'center', paddingHorizontal: 4 },
  confirmationButtonText: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  kicker: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.7 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 28, letterSpacing: -0.9, marginTop: 5 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 5 },
  emptyCard: {
    minHeight: 290,
    borderRadius: 24,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyIcon: {
    width: 56,
    height: 56,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 15,
  },
  emptyTitle: { fontFamily: 'Inter_700Bold', fontSize: 18, textAlign: 'center' },
  emptyBody: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    lineHeight: 18,
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 19,
    maxWidth: 250,
  },
  primaryButton: {
    height: 52,
    borderRadius: 17,
    paddingHorizontal: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 11,
  },
  primaryButtonText: {
    color: '#fffdf9',
    fontFamily: 'Inter_700Bold',
    fontSize: 13,
  },
  itemsList: { gap: 10 },
  cartItem: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 19,
    borderWidth: 1,
    padding: 9,
    minHeight: 112,
    gap: 11,
  },
  itemImage: { width: 80, height: 88, borderRadius: 13 },
  itemCopy: { flex: 1, alignSelf: 'stretch', justifyContent: 'center' },
  itemName: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  itemDetails: { fontFamily: 'Inter_400Regular', fontSize: 9, lineHeight: 13, marginTop: 4 },
  itemPrice: { fontFamily: 'Inter_700Bold', fontSize: 12, marginTop: 6 },
  quantityControl: {
    flexDirection: 'row',
    height: 34,
    paddingHorizontal: 5,
    borderRadius: 12,
    alignItems: 'center',
    gap: 3,
  },
  quantityButton: { width: 24, height: 30, alignItems: 'center', justifyContent: 'center' },
  quantity: {
    minWidth: 17,
    textAlign: 'center',
    fontFamily: 'Inter_700Bold',
    fontSize: 12,
  },
  summary: { padding: 17, borderRadius: 20, marginTop: 17, gap: 12 },
  summaryLine: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  summaryLabel: { fontFamily: 'Inter_400Regular', fontSize: 12 },
  summaryValue: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  totalLine: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    paddingTop: 13,
    marginTop: 1,
  },
  totalLabel: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  totalValue: { fontFamily: 'Inter_700Bold', fontSize: 19 },
  checkoutButton: { marginTop: 14 },
  demoCaption: { textAlign: 'center', fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 10 },
});
