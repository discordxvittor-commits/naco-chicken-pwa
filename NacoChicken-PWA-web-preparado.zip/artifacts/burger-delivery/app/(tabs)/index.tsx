import React, { useMemo, useState } from 'react';
import {
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { MENU_PRODUCTS, formatPrice } from '@/constants/menu';
import { useCart } from '@/context/CartContext';

const CATEGORIES = [
  'Todos',
  'Hambúrgueres',
  'Frango',
  'Lanches',
  'Acompanhamentos',
] as const;

export default function MenuScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { addItem, cartCount } = useCart();
  const [category, setCategory] =
    useState<(typeof CATEGORIES)[number]>('Todos');
  const [addedProduct, setAddedProduct] = useState<string | null>(null);

  const products = useMemo(
    () =>
      category === 'Todos'
        ? MENU_PRODUCTS
        : MENU_PRODUCTS.filter((product) => product.category === category),
    [category],
  );

  async function addProduct(productId: string) {
    try {
      await addItem(productId);
      setAddedProduct(productId);
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      setTimeout(() => setAddedProduct(null), 900);
    } catch {
      setAddedProduct(null);
    }
  }

  return (
    <ScrollView
      style={[styles.screen, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop:
            Platform.OS === 'web' ? 67 : Math.max(insets.top, 12) + 8,
        },
      ]}
      contentInsetAdjustmentBehavior="automatic"
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.topBar}>
        <Image
          accessibilityLabel="NacoChicken Fish and Chips"
          source={require('../../assets/images/naco-logo.jpg')}
          resizeMode="contain"
          style={styles.brandLogo}
        />
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Abrir carrinho com ${cartCount} itens`}
          testID="home-cart-button"
          onPress={() => router.push('/(tabs)/cart')}
          style={({ pressed }) => [
            styles.cartShortcut,
            { backgroundColor: colors.card, opacity: pressed ? 0.72 : 1 },
          ]}
        >
          <Feather name="shopping-bag" size={19} color={colors.foreground} />
          {cartCount > 0 && (
            <View style={[styles.cartDot, { backgroundColor: colors.primary }]}>
              <Text
                style={[
                  styles.cartDotText,
                  { color: colors.primaryForeground },
                ]}
              >
                {cartCount > 9 ? '9+' : cartCount}
              </Text>
            </View>
          )}
        </Pressable>
      </View>

      <View style={[styles.deliveryLine, { borderColor: colors.border }]}>
        <Feather name="map-pin" size={14} color={colors.primary} />
        <Text style={[styles.deliveryText, { color: colors.mutedForeground }]}>
          Entrega NacoChicken
        </Text>
        <View style={styles.deliveryTime}>
          <Feather name="dollar-sign" size={13} color={colors.foreground} />
          <Text style={[styles.deliveryTimeText, { color: colors.foreground }]}>
            Meticais (MZN)
          </Text>
        </View>
      </View>

      <View style={[styles.hero, { backgroundColor: colors.primary }]}>
        <Image
          source={MENU_PRODUCTS[0].image}
          style={styles.heroImage}
          resizeMode="cover"
        />
        <View
          style={[
            styles.heroShade,
            { backgroundColor: colors.primary, opacity: 0.62 },
          ]}
        />
        <View style={styles.heroCopy}>
          <Text style={[styles.heroEyebrow, { color: colors.accent }]}>
            DESTAQUE DO CATÁLOGO
          </Text>
          <Text style={[styles.heroTitle, { color: colors.primaryForeground }]}>
            {MENU_PRODUCTS[0].name}
          </Text>
          <View style={styles.heroPriceRow}>
            <Text style={[styles.heroPrice, { color: colors.primaryForeground }]}>
              {formatPrice(MENU_PRODUCTS[0].price)}
            </Text>
            <Text style={[styles.heroDot, { color: colors.accent }]}>·</Text>
            <Text
              style={[styles.heroDetail, { color: colors.primaryForeground }]}
              numberOfLines={2}
            >
              {MENU_PRODUCTS[0].description}
            </Text>
          </View>
          <Pressable
            accessibilityRole="button"
            testID="hero-add-button"
            onPress={() => void addProduct(MENU_PRODUCTS[0].id)}
            style={({ pressed }) => [
              styles.heroButton,
              {
                backgroundColor: colors.accent,
                opacity: pressed ? 0.82 : 1,
              },
            ]}
          >
            <Text style={[styles.heroButtonText, { color: colors.accentForeground }]}>
              {addedProduct === MENU_PRODUCTS[0].id ? 'Adicionado' : 'Pedir agora'}
            </Text>
            <Feather
              name="arrow-up-right"
              size={17}
              color={colors.accentForeground}
            />
          </Pressable>
        </View>
        <View
          style={[
            styles.heroImageEdge,
            { borderColor: colors.primaryForeground },
          ]}
        />
      </View>

      <View style={styles.sectionHeading}>
        <View>
          <Text style={[styles.kicker, { color: colors.primary }]}>
            NACOCHICKEN FISH AND CHIPS
          </Text>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            O catálogo
          </Text>
        </View>
        <View style={[styles.freshBadge, { backgroundColor: colors.accent }]}>
          <Text style={[styles.freshBadgeText, { color: colors.accentForeground }]}>
            {MENU_PRODUCTS.length} opções
          </Text>
        </View>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.categoryScroll}
        contentContainerStyle={styles.categoryList}
      >
        {CATEGORIES.map((item) => {
          const selected = category === item;
          return (
            <Pressable
              key={item}
              accessibilityRole="button"
              accessibilityState={{ selected }}
              testID={`category-${item.toLowerCase()}`}
              onPress={() => setCategory(item)}
              style={[
                styles.categoryPill,
                {
                  backgroundColor: selected ? colors.primary : colors.card,
                  borderColor: selected ? colors.primary : colors.border,
                },
              ]}
            >
              <Text
                style={[
                  styles.categoryText,
                  {
                    color: selected
                      ? colors.primaryForeground
                      : colors.foreground,
                  },
                ]}
              >
                {item}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <View style={styles.productGrid}>
        {products.map((product) => (
          <View
            key={product.id}
            style={[
              styles.productCard,
              { backgroundColor: colors.card, borderColor: colors.border },
            ]}
          >
            <View style={styles.productImageWrap}>
              <Image
                source={product.image}
                style={styles.productImage}
                resizeMode="cover"
                accessibilityLabel={`Foto de ${product.name}`}
              />
              {product.tag && (
                <View style={[styles.productTag, { backgroundColor: colors.accent }]}>
                  <Text style={[styles.productTagText, { color: colors.accentForeground }]}>
                    {product.tag}
                  </Text>
                </View>
              )}
            </View>
            <View style={styles.productCopy}>
              <Text style={[styles.productName, { color: colors.foreground }]}>
                {product.name}
              </Text>
              <Text
                style={[styles.productDescription, { color: colors.mutedForeground }]}
                numberOfLines={2}
              >
                {product.description}
              </Text>
              <View style={styles.productBottom}>
                <Text style={[styles.productPrice, { color: colors.foreground }]}>
                  {formatPrice(product.price)}
                </Text>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={`Adicionar ${product.name} ao carrinho`}
                  testID={`add-${product.id}`}
                  onPress={() => void addProduct(product.id)}
                  style={({ pressed }) => [
                    styles.addButton,
                    { backgroundColor: colors.primary, opacity: pressed ? 0.75 : 1 },
                  ]}
                >
                  <Feather
                    name={addedProduct === product.id ? 'check' : 'plus'}
                    size={18}
                    color={colors.primaryForeground}
                  />
                </Pressable>
              </View>
            </View>
          </View>
        ))}
      </View>
      <View style={[styles.demoNote, { backgroundColor: colors.muted }]}>
        <Feather name="info" size={15} color={colors.mutedForeground} />
        <Text style={[styles.demoNoteText, { color: colors.mutedForeground }]}>
          Produtos e preços conforme o catálogo enviado. Pedidos e pagamentos ainda não são enviados à loja.
        </Text>
      </View>
      <View style={{ height: Platform.OS === 'web' ? 112 : 92 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 20, paddingBottom: 16 },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  brandLogo: { width: 128, height: 66 },
  cartShortcut: {
    width: 44,
    height: 44,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cartDot: {
    position: 'absolute',
    right: -4,
    top: -4,
    height: 19,
    minWidth: 19,
    borderRadius: 10,
    paddingHorizontal: 4,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cartDotText: { fontFamily: 'Inter_700Bold', fontSize: 10 },
  deliveryLine: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    paddingBottom: 14,
    marginBottom: 18,
    gap: 7,
  },
  deliveryText: { fontFamily: 'Inter_500Medium', fontSize: 12, flex: 1 },
  deliveryTime: { flexDirection: 'row', gap: 5, alignItems: 'center' },
  deliveryTimeText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  hero: {
    height: 230,
    borderRadius: 24,
    overflow: 'hidden',
    marginBottom: 27,
    justifyContent: 'center',
  },
  heroImage: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    opacity: 0.7,
  },
  heroShade: { ...StyleSheet.absoluteFill },
  heroCopy: { paddingHorizontal: 21, paddingVertical: 18, zIndex: 2 },
  heroEyebrow: {
    fontFamily: 'Inter_700Bold',
    fontSize: 9,
    letterSpacing: 1.6,
    marginBottom: 9,
  },
  heroTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 30,
    lineHeight: 34,
    letterSpacing: -1,
  },
  heroPriceRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8 },
  heroPrice: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  heroDot: { fontSize: 18 },
  heroDetail: {
    fontFamily: 'Inter_400Regular',
    fontSize: 10,
    flexShrink: 1,
  },
  heroButton: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 14,
    height: 38,
    borderRadius: 13,
    marginTop: 13,
  },
  heroButtonText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  heroImageEdge: {
    position: 'absolute',
    right: -28,
    bottom: -41,
    width: 132,
    height: 132,
    borderWidth: 1,
    borderRadius: 70,
    opacity: 0.28,
  },
  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  kicker: {
    fontFamily: 'Inter_700Bold',
    fontSize: 9,
    letterSpacing: 1.5,
    marginBottom: 4,
  },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 23, letterSpacing: -0.7 },
  freshBadge: { borderRadius: 10, paddingVertical: 6, paddingHorizontal: 9 },
  freshBadgeText: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  categoryScroll: { marginHorizontal: -20, marginBottom: 15 },
  categoryList: { paddingHorizontal: 20, gap: 8 },
  categoryPill: {
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 15,
    paddingVertical: 9,
  },
  categoryText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  productGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  productCard: {
    width: '48%',
    flexGrow: 1,
    flexBasis: '44%',
    borderRadius: 20,
    borderWidth: 1,
    padding: 8,
  },
  productImageWrap: {
    height: 124,
    borderRadius: 15,
    overflow: 'hidden',
  },
  productImage: { width: '100%', height: '100%' },
  productTag: {
    position: 'absolute',
    left: 7,
    top: 7,
    borderRadius: 8,
    paddingVertical: 5,
    paddingHorizontal: 7,
  },
  productTagText: { fontFamily: 'Inter_700Bold', fontSize: 8 },
  productCopy: { paddingHorizontal: 3, paddingTop: 10, paddingBottom: 3 },
  productName: { fontFamily: 'Inter_700Bold', fontSize: 14, letterSpacing: -0.2 },
  productDescription: {
    fontFamily: 'Inter_400Regular',
    fontSize: 10,
    lineHeight: 14,
    minHeight: 28,
    marginTop: 4,
  },
  productBottom: {
    marginTop: 9,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  productPrice: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  addButton: {
    width: 32,
    height: 32,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  demoNote: {
    marginTop: 18,
    flexDirection: 'row',
    gap: 8,
    borderRadius: 14,
    padding: 12,
    alignItems: 'flex-start',
  },
  demoNoteText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15 },
});
