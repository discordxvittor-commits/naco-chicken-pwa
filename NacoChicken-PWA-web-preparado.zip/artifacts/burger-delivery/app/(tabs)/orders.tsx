import React, { useState } from 'react';
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { formatPrice } from '@/constants/menu';
import {
  getOrderCurrency,
  getPaymentMethodLabel,
  useCart,
} from '@/context/CartContext';

export default function OrdersScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { orders, isHydrated, deleteOrder } = useCart();
  const [pendingDeleteOrderId, setPendingDeleteOrderId] = useState<string | null>(
    null,
  );
  const [deleteOrderError, setDeleteOrderError] = useState('');

  async function confirmDeleteOrder(orderId: string) {
    setDeleteOrderError('');
    try {
      await deleteOrder(orderId);
      setPendingDeleteOrderId(null);
    } catch {
      setDeleteOrderError('Não foi possível apagar o pedido. Tente novamente.');
    }
  }

  return (
    <ScrollView
      style={[styles.screen, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: Platform.OS === 'web' ? 67 : Math.max(insets.top, 12) + 12,
          paddingBottom: 104,
        },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <Text style={[styles.kicker, { color: colors.primary }]}>SUA HISTÓRIA</Text>
      <Text style={[styles.title, { color: colors.foreground }]}>Meus pedidos</Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
        Acompanhe os pedidos feitos neste aparelho.
      </Text>

      {!isHydrated ? (
        <View style={[styles.emptyCard, { backgroundColor: colors.card }]}>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
            Carregando pedidos...
          </Text>
        </View>
      ) : orders.length === 0 ? (
        <View style={[styles.emptyCard, { backgroundColor: colors.card }]}>
          <View style={[styles.emptyIcon, { backgroundColor: colors.muted }]}>
            <Feather name="file-text" size={22} color={colors.primary} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
            Ainda não há pedidos
          </Text>
          <Text style={[styles.emptyBody, { color: colors.mutedForeground }]}>
            Seu próximo burger favorito começa no cardápio.
          </Text>
          <Pressable
            accessibilityRole="button"
            testID="orders-browse-menu"
            onPress={() => router.navigate('/(tabs)')}
            style={({ pressed }) => [
              styles.primaryButton,
              { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
            ]}
          >
            <Text style={styles.primaryButtonText}>Ver menu</Text>
            <Feather name="arrow-right" size={16} color={colors.primaryForeground} />
          </Pressable>
        </View>
      ) : (
        <View style={styles.orderList}>
          {orders.map((order) => (
            <View
              key={order.id}
              style={[
                styles.orderCard,
                { backgroundColor: colors.card, borderColor: colors.border },
              ]}
            >
              <View style={styles.orderTop}>
                <View>
                  <Text style={[styles.orderNumber, { color: colors.foreground }]}>
                    Pedido #{order.id.slice(-5)}
                  </Text>
                  <Text style={[styles.orderDate, { color: colors.mutedForeground }]}>
                    {new Date(order.createdAt).toLocaleDateString('pt-MZ', {
                      day: '2-digit',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </Text>
                  <Text style={[styles.orderDate, { color: colors.mutedForeground }]}>
                    Pagamento: {getPaymentMethodLabel(order.paymentMethod)}
                  </Text>
                </View>
                <View style={styles.orderTopActions}>
                  <View style={[styles.demoPill, { backgroundColor: colors.accent }]}>
                    <Text style={[styles.demoPillText, { color: colors.accentForeground }]}>
                      Demonstração
                    </Text>
                  </View>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={`Apagar pedido ${order.id.slice(-5)}`}
                    testID={`delete-order-${order.id}`}
                    onPress={() => {
                      setDeleteOrderError('');
                      setPendingDeleteOrderId(order.id);
                    }}
                    style={[
                      styles.deleteOrderButton,
                      { backgroundColor: colors.muted },
                    ]}
                  >
                    <Feather name="trash-2" size={15} color={colors.destructive} />
                  </Pressable>
                </View>
              </View>
              {pendingDeleteOrderId === order.id && (
                <View style={[styles.deleteConfirmation, { backgroundColor: colors.muted }]}>
                  <Text style={[styles.deleteConfirmationText, { color: colors.foreground }]}>
                    Apagar do histórico deste aparelho? Isto não cancela um pedido enviado à loja.
                  </Text>
                  {!!deleteOrderError && (
                    <Text style={[styles.deleteConfirmationError, { color: colors.destructive }]}>
                      {deleteOrderError}
                    </Text>
                  )}
                  <View style={styles.deleteConfirmationActions}>
                    <Pressable
                      accessibilityRole="button"
                      onPress={() => setPendingDeleteOrderId(null)}
                      style={styles.deleteConfirmationAction}
                    >
                      <Text style={[styles.deleteConfirmationActionText, { color: colors.foreground }]}>
                        Manter
                      </Text>
                    </Pressable>
                    <Pressable
                      accessibilityRole="button"
                      testID={`confirm-delete-order-${order.id}`}
                      onPress={() => void confirmDeleteOrder(order.id)}
                      style={styles.deleteConfirmationAction}
                    >
                      <Text style={[styles.deleteConfirmationActionText, { color: colors.destructive }]}>
                        Apagar pedido
                      </Text>
                    </Pressable>
                  </View>
                </View>
              )}
              <View style={[styles.orderDivider, { borderColor: colors.border }]} />
              {order.items.map((item) => (
                <View key={`${order.id}-${item.productId}`} style={styles.orderLine}>
                  <Text style={[styles.orderItemName, { color: colors.mutedForeground }]}>
                    {item.quantity} × {item.name}
                  </Text>
                  <Text style={[styles.orderItemPrice, { color: colors.foreground }]}>
                    {formatPrice(
                      item.unitPrice * item.quantity,
                      getOrderCurrency(order),
                    )}
                  </Text>
                </View>
              ))}
              <View style={styles.orderBottom}>
                <Text style={[styles.orderStatus, { color: colors.primary }]}>
                  Salvo neste aparelho
                </Text>
                <Text style={[styles.orderTotal, { color: colors.foreground }]}>
                  {formatPrice(order.total, getOrderCurrency(order))}
                </Text>
              </View>
            </View>
          ))}
        </View>
      )}
      <View style={[styles.disclaimer, { backgroundColor: colors.muted }]}>
        <Feather name="info" size={15} color={colors.mutedForeground} />
        <Text style={[styles.disclaimerText, { color: colors.mutedForeground }]}>
          Pedidos de demonstração não são enviados à hamburgueria.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 20 },
  kicker: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.7 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 28, letterSpacing: -0.9, marginTop: 5 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 5, marginBottom: 22 },
  emptyCard: {
    minHeight: 282,
    borderRadius: 24,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyIcon: {
    width: 56,
    height: 56,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 15,
  },
  emptyTitle: { fontFamily: 'Inter_700Bold', fontSize: 18, textAlign: 'center' },
  emptyBody: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    lineHeight: 18,
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 19,
    maxWidth: 250,
  },
  primaryButton: {
    height: 50,
    borderRadius: 16,
    paddingHorizontal: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  primaryButtonText: { color: '#fffdf9', fontFamily: 'Inter_700Bold', fontSize: 13 },
  orderList: { gap: 12 },
  orderCard: { borderRadius: 20, borderWidth: 1, padding: 16 },
  orderTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  orderTopActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  deleteOrderButton: {
    width: 32,
    height: 32,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  deleteConfirmation: { borderRadius: 13, padding: 12, marginTop: 12 },
  deleteConfirmationText: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15 },
  deleteConfirmationError: { fontFamily: 'Inter_500Medium', fontSize: 10, marginTop: 7 },
  deleteConfirmationActions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 10,
  },
  deleteConfirmationAction: { minHeight: 32, justifyContent: 'center', paddingHorizontal: 3 },
  deleteConfirmationActionText: { fontFamily: 'Inter_700Bold', fontSize: 10 },
  orderNumber: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  orderDate: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 4 },
  demoPill: { paddingHorizontal: 9, paddingVertical: 6, borderRadius: 10 },
  demoPillText: { fontFamily: 'Inter_700Bold', fontSize: 9 },
  orderDivider: { borderTopWidth: 1, marginVertical: 13 },
  orderLine: { flexDirection: 'row', justifyContent: 'space-between', gap: 10, marginBottom: 9 },
  orderItemName: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 11 },
  orderItemPrice: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  orderBottom: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 5 },
  orderStatus: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  orderTotal: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  disclaimer: { marginTop: 16, borderRadius: 14, padding: 12, flexDirection: 'row', gap: 8 },
  disclaimerText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15 },
});
