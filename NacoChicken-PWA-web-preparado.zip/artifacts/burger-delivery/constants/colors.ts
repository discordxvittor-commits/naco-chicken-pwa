/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#46170f',
    tint: '#c30019',

    // Core surfaces
    background: '#fff6ea',
    foreground: '#46170f',

    // Cards / elevated surfaces
    card: '#fffdf9',
    cardForeground: '#46170f',

    // Primary action color (buttons, links, active states)
    primary: '#c30019',
    primaryForeground: '#fff9ea',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#f8e4d6',
    secondaryForeground: '#46170f',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#f5e8d8',
    mutedForeground: '#805447',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#f5bd35',
    accentForeground: '#46170f',

    // Destructive actions (delete, error states)
    destructive: '#c30019',
    destructiveForeground: '#fff9ea',

    // WhatsApp contact action
    whatsapp: '#25D366',
    whatsappForeground: '#ffffff',

    // Borders and input outlines
    border: '#e9d2c1',
    input: '#e9d2c1',
  },

  // Border radius in pixels
  radius: 18,
};

export default colors;
