import type { ImageSourcePropType } from 'react-native';

export type MenuCategory =
  | 'Hambúrgueres'
  | 'Frango'
  | 'Lanches'
  | 'Acompanhamentos';

export interface MenuProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  category: MenuCategory;
  image: ImageSourcePropType;
  tag?: string;
}

export const MENU_PRODUCTS: MenuProduct[] = [
  {
    id: 'hamburguer-classic',
    name: 'Hamburguer Classic',
    description: 'Hambúrguer simples + batata',
    price: 299,
    category: 'Hambúrgueres',
    image: require('../assets/images/catalog/hamburguer-classic.jpg'),
  },
  {
    id: 'big-mac',
    name: 'Big Mac',
    description: 'Hambúrguer duplo + batata',
    price: 485,
    category: 'Hambúrgueres',
    image: require('../assets/images/catalog/big-mac.jpg'),
  },
  {
    id: 'chicken-burger-classic',
    name: 'Chicken Burguer Classic',
    description: 'Hambúrguer de frango + batata',
    price: 315,
    category: 'Frango',
    image: require('../assets/images/catalog/chicken-burger-classic.jpg'),
  },
  {
    id: 'naco-prego',
    name: 'Naco Prego',
    description: 'Prego de carne de vaca, queijo e molho especial',
    price: 248,
    category: 'Lanches',
    image: require('../assets/images/catalog/naco-prego.jpg'),
  },
  {
    id: 'double-chicken-burger',
    name: 'Double Chicken Burguer',
    description: 'Hambúrguer de frango duplo + batata',
    price: 589,
    category: 'Frango',
    image: require('../assets/images/catalog/double-chicken-burger.jpg'),
  },
  {
    id: 'prego-frango-deluxe',
    name: 'Prego Frango Deluxe',
    description: 'Peito de frango, queijo, ovo e molho especial',
    price: 265,
    category: 'Lanches',
    image: require('../assets/images/catalog/prego-frango-deluxe.jpg'),
  },
  {
    id: 'single-chicken-quarter',
    name: 'Single Chicken 1/4',
    description: 'Frango com batata',
    price: 249,
    category: 'Frango',
    image: require('../assets/images/catalog/single-chicken-quarter.jpg'),
  },
  {
    id: 'dose-batata',
    name: 'Dose de Batata',
    description: 'Batata frita',
    price: 99,
    category: 'Acompanhamentos',
    image: require('../assets/images/catalog/dose-batata.jpg'),
  },
  {
    id: 'fried-chicken-half',
    name: 'Friend Chicken 1/2',
    description: 'Frango com batata',
    price: 485,
    category: 'Frango',
    image: require('../assets/images/catalog/fried-chicken-half.jpg'),
  },
  {
    id: 'family-chicken',
    name: 'Family Chicken',
    description: 'Frango inteiro',
    price: 995,
    category: 'Frango',
    image: require('../assets/images/catalog/family-chicken.jpg'),
  },
  {
    id: 'hot-dog',
    name: 'Hot Dog',
    description: 'Cachorro-quente + batata',
    price: 239,
    category: 'Lanches',
    image: require('../assets/images/catalog/hot-dog.jpg'),
  },
  {
    id: 'six-asinhas',
    name: '6 Asinhas Grelhadas',
    description: 'Asinhas grelhadas com batata',
    price: 229,
    category: 'Frango',
    image: require('../assets/images/catalog/six-asinhas.jpg'),
  },
  {
    id: 'sandes',
    name: 'Sandes',
    description: 'Ovo + queijo',
    price: 99,
    category: 'Lanches',
    image: require('../assets/images/catalog/sandes.jpg'),
  },
  {
    id: 'twelve-asinhas',
    name: '12 Asinhas Grelhadas',
    description: 'Asinhas grelhadas com batata',
    price: 425,
    category: 'Frango',
    image: require('../assets/images/catalog/twelve-asinhas.jpg'),
  },
  {
    id: 'grooveland',
    name: 'GrooveLand',
    description: 'Moelas picantes + batatas',
    price: 215,
    category: 'Frango',
    image: require('../assets/images/catalog/grooveland.jpg'),
  },
  {
    id: 'eighteen-asinhas',
    name: '18 Asinhas Grelhadas',
    description: 'Asinhas grelhadas com batata',
    price: 629,
    category: 'Frango',
    image: require('../assets/images/catalog/eighteen-asinhas.jpg'),
  },
];

export function formatPrice(value: number, currency: 'MZN' | 'BRL' = 'MZN') {
  return new Intl.NumberFormat(currency === 'MZN' ? 'pt-MZ' : 'pt-BR', {
    style: 'currency',
    currency,
    currencyDisplay: 'code',
    ...(currency === 'MZN'
      ? { minimumFractionDigits: 0, maximumFractionDigits: 0 }
      : {}),
  }).format(value);
}
