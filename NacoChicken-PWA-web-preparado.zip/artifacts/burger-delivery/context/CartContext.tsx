import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { MENU_PRODUCTS } from '@/constants/menu';

const CART_STORAGE_KEY = 'brasa-pao-cart-v1';
const ORDERS_STORAGE_KEY = 'brasa-pao-orders-v1';
const DELIVERY_FEE = 100;

export type PaymentMethod = 'emola' | 'mpesa';

export interface CartLine {
  productId: string;
  quantity: number;
}

export interface OrderLine {
  productId: string;
  name: string;
  unitPrice: number;
  quantity: number;
}

export interface DemoOrder {
  id: string;
  customerName: string;
  address: string;
  items: OrderLine[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  createdAt: number;
  paymentMethod: PaymentMethod | 'card-demo';
  currency?: 'MZN' | 'BRL';
}

interface CheckoutDetails {
  customerName: string;
  address: string;
  paymentMethod: PaymentMethod;
}

export function getOrderCurrency(order: Pick<DemoOrder, 'currency' | 'paymentMethod'>) {
  return order.currency ?? (order.paymentMethod === 'card-demo' ? 'BRL' : 'MZN');
}

export function getPaymentMethodLabel(paymentMethod: DemoOrder['paymentMethod']) {
  if (paymentMethod === 'emola') return 'eMola';
  if (paymentMethod === 'mpesa') return 'M-Pesa';
  return 'Cartão (pedido anterior)';
}

interface CartContextValue {
  cart: CartLine[];
  orders: DemoOrder[];
  cartCount: number;
  subtotal: number;
  deliveryFee: number;
  total: number;
  isHydrated: boolean;
  addItem: (productId: string) => Promise<void>;
  removeItem: (productId: string) => Promise<void>;
  clearCart: () => Promise<void>;
  deleteOrder: (orderId: string) => Promise<void>;
  createDemoOrder: (details: CheckoutDetails) => Promise<DemoOrder>;
}

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartLine[]>([]);
  const [orders, setOrders] = useState<DemoOrder[]>([]);
  const [isHydrated, setIsHydrated] = useState(false);
  const cartRef = useRef<CartLine[]>([]);
  const ordersRef = useRef<DemoOrder[]>([]);

  useEffect(() => {
    let active = true;

    async function restoreLocalData() {
      try {
        const [storedCart, storedOrders] = await Promise.all([
          AsyncStorage.getItem(CART_STORAGE_KEY),
          AsyncStorage.getItem(ORDERS_STORAGE_KEY),
        ]);

        if (!active) return;

        const restoredCart = storedCart
          ? (JSON.parse(storedCart) as CartLine[])
          : [];
        const restoredOrders = storedOrders
          ? (JSON.parse(storedOrders) as DemoOrder[])
          : [];

        cartRef.current = restoredCart;
        ordersRef.current = restoredOrders;
        setCart(restoredCart);
        setOrders(restoredOrders);
      } finally {
        if (active) setIsHydrated(true);
      }
    }

    void restoreLocalData();

    return () => {
      active = false;
    };
  }, []);

  const addItem = useCallback(async (productId: string) => {
    const nextCart = [...cartRef.current];
    const existingLine = nextCart.find((line) => line.productId === productId);

    if (existingLine) {
      existingLine.quantity += 1;
    } else {
      nextCart.push({ productId, quantity: 1 });
    }

    await AsyncStorage.setItem(CART_STORAGE_KEY, JSON.stringify(nextCart));
    cartRef.current = nextCart;
    setCart(nextCart);
  }, []);

  const removeItem = useCallback(async (productId: string) => {
    const nextCart = cartRef.current
      .map((line) =>
        line.productId === productId
          ? { ...line, quantity: line.quantity - 1 }
          : line,
      )
      .filter((line) => line.quantity > 0);

    await AsyncStorage.setItem(CART_STORAGE_KEY, JSON.stringify(nextCart));
    cartRef.current = nextCart;
    setCart(nextCart);
  }, []);

  const clearCart = useCallback(async () => {
    await AsyncStorage.setItem(CART_STORAGE_KEY, JSON.stringify([]));
    cartRef.current = [];
    setCart([]);
  }, []);

  const deleteOrder = useCallback(async (orderId: string) => {
    const nextOrders = ordersRef.current.filter((order) => order.id !== orderId);
    await AsyncStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(nextOrders));
    ordersRef.current = nextOrders;
    setOrders(nextOrders);
  }, []);

  const createDemoOrder = useCallback(
    async ({ customerName, address, paymentMethod }: CheckoutDetails) => {
      const items = cartRef.current.flatMap((line) => {
        const product = MENU_PRODUCTS.find(
          (menuProduct) => menuProduct.id === line.productId,
        );

        return product
          ? [
              {
                productId: product.id,
                name: product.name,
                unitPrice: product.price,
                quantity: line.quantity,
              },
            ]
          : [];
      });

      if (items.length === 0) {
        throw new Error('Adicione um hambúrguer antes de concluir o pedido.');
      }

      const subtotal = items.reduce(
        (sum, item) => sum + item.unitPrice * item.quantity,
        0,
      );
      const order: DemoOrder = {
        id: String(Date.now()),
        customerName: customerName.trim(),
        address: address.trim(),
        items,
        subtotal,
        deliveryFee: DELIVERY_FEE,
        total: subtotal + DELIVERY_FEE,
        createdAt: Date.now(),
        paymentMethod,
        currency: 'MZN',
      };
      const nextOrders = [order, ...ordersRef.current];

      await Promise.all([
        AsyncStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(nextOrders)),
        AsyncStorage.setItem(CART_STORAGE_KEY, JSON.stringify([])),
      ]);

      ordersRef.current = nextOrders;
      cartRef.current = [];
      setOrders(nextOrders);
      setCart([]);
      return order;
    },
    [],
  );

  const cartCount = cart.reduce((sum, line) => sum + line.quantity, 0);
  const subtotal = cart.reduce((sum, line) => {
    const product = MENU_PRODUCTS.find(
      (menuProduct) => menuProduct.id === line.productId,
    );
    return sum + (product?.price ?? 0) * line.quantity;
  }, 0);
  const deliveryFee = cartCount > 0 ? DELIVERY_FEE : 0;
  const value = useMemo(
    () => ({
      cart,
      orders,
      cartCount,
      subtotal,
      deliveryFee,
      total: subtotal + deliveryFee,
      isHydrated,
      addItem,
      removeItem,
      clearCart,
      deleteOrder,
      createDemoOrder,
    }),
    [
      cart,
      orders,
      cartCount,
      subtotal,
      deliveryFee,
      isHydrated,
      addItem,
      removeItem,
      clearCart,
      deleteOrder,
      createDemoOrder,
    ],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within CartProvider');
  }
  return context;
}
