# Naco Chicken — preparação PWA

Esta pasta é a aplicação Expo dentro do monorepo. Os ficheiros PWA foram adicionados, mas a compilação ainda precisa de ser executada e testada.

## Compilar no ambiente do projeto

Na raiz do monorepo (a pasta que contém `pnpm-workspace.yaml`):

```bash
pnpm install
pnpm --filter @workspace/burger-delivery export:web
```

A exportação deve criar `artifacts/burger-delivery/dist`. Se houver erro, não publique ainda; corrija primeiro o erro de compilação.

## Publicar

Depois de confirmar que a compilação terminou sem erros, publique o CONTEÚDO da pasta `artifacts/burger-delivery/dist` num alojamento estático HTTPS, por exemplo Netlify. Não publique o ZIP do código-fonte.

## Instalação

Abra o URL HTTPS no Chrome Android. Use o menu do navegador e escolha “Instalar app” ou “Adicionar ao ecrã inicial”, conforme a opção apresentada. No iPhone, abra no Safari e use Partilhar > Adicionar ao ecrã principal.

Nota: ainda é necessário testar o menu, o carrinho, a navegação e o envio de pedidos por WhatsApp no navegador. O service worker não guarda pedidos nem dados pessoais em cache.
